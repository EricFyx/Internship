/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import junit.framework.TestCase;

/**
 *
 * @author Eric
 */
public class CartItemTest extends TestCase {
    Book book = new Book("1234567", "Book 1", "Author 1", 100.00);
    CartItem cartItem = null;
    public CartItemTest(String testName) {
        super(testName);
        cartItem = new CartItem(book);
        cartItem.setQuantity(5);
        cartItem.updateQuantity(10);
      
   
    }
         //CartItem cartItem = new CartItem(book);

         //CartItem cartItem = new CartItem(new Book("1234567", "Book 1", "Author 1", 100.00));
    /**
     * Test of setQuantity method, of class CartItem.
     */
//    public void testSetQuantity() {
//        System.out.println("setQuantity");
//        int aQuantity = 2;
//        CartItem instance = cartItem;
//        instance.setQuantity(aQuantity);
//    }
//
//    /**
//     * Test of updateQuantity method, of class CartItem.
//     */
//    public void testUpdateQuantity() {
//        System.out.println("updateQuantity");
//        int newQuantity = 4;
//        CartItem instance = cartItem;
//        instance.updateQuantity(newQuantity);
//
//    }

    /**
     * Test of getDollarOrderCost method, of class CartItem.
     */
    public void testGetDollarOrderCost() {
        System.out.println("getDollarOrderCost");
        CartItem instance = cartItem;
        String expResult = "$1000.00";
        String result = instance.getDollarOrderCost();
        assertEquals(expResult, result);

    }

    /**
     * Test of toString method, of class CartItem.
     */
//    public void testToString() {
//        System.out.println("toString");
//        CartItem instance = cartItem;
//        String expResult = "Title: Book 1     ";
//        String result = instance.toString();
//        assertEquals(expResult, result);
//
//    }

    /**
     * Test of getBook method, of class CartItem.
     */
    public void testGetBook() {
        System.out.println("getBook");
        CartItem instance = cartItem;
        Book expResult = book ;
        Book result = instance.getBook();
        assertEquals(expResult, result);

    }

    /**
     * Test of getOrderCost method, of class CartItem.
     */
    public void testGetOrderCost() {
        System.out.println("getOrderCost");
        CartItem instance = cartItem;
        double expResult = 1000.00;
        double result = instance.getOrderCost();
        assertEquals(expResult, result);

    }

    /**
     * Test of getQuantity method, of class CartItem.
     */
    public void testGetQuantity() {
        System.out.println("getQuantity");
        CartItem instance = cartItem;
        int expResult = 10;
        int result = instance.getQuantity();
        assertEquals(expResult, result);

    }
    
}
