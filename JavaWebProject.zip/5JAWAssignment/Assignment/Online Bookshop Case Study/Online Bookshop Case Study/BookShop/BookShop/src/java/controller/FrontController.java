package controller;

import dispatchers.addToCartDispatcher;
import dispatchers.checkOutDispatcher;
import dispatchers.continueDispatcher;
import dispatchers.dispatcher;
import dispatchers.homeDispatcher;
import dispatchers.titleDispatcher;
import dispatchers.updateCartDispatcher;
import dispatchers.viewCartDispatcher;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
//import dispatchers.*;
import model.Book;
import model.CartItem;
import utility.AdmitBookStoreDAO;


@WebServlet(name = "FrontController", urlPatterns = {"/FrontController"}, initParams = {
    @WebInitParam(name = "datasource", value = "jdbc/JavaDB_BooksDB")})
public class FrontController extends HttpServlet {
  private final HashMap dispatchers = new HashMap();

  //Initialize global variables
  public void init(ServletConfig config) throws ServletException {
    super.init(config);
        dispatchers.put("home", new homeDispatcher());
        dispatchers.put("title", new titleDispatcher());
        dispatchers.put("continue", new continueDispatcher());
        dispatchers.put("add_to_cart", new addToCartDispatcher());
        dispatchers.put("checkout", new checkOutDispatcher());
        dispatchers.put("update_cart", new updateCartDispatcher());
        dispatchers.put("view_cart", new viewCartDispatcher());

    

  }

   //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    System.err.println("doGet()");
    doPost(request,response);

  }

  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     response.setContentType("text/html");
     String next_view = "no view ";
     String requestAction = request.getParameter("action");
     if(requestAction == null)
     {
         requestAction = "title";
     }
     String d = this.getInitParameter("datasource");
     HttpSession session = request.getSession();
     AdmitBookStoreDAO dao = new AdmitBookStoreDAO(d);
     String nextPage = "";
     
     dispatcher action = (dispatcher) dispatchers.get(requestAction);
     nextPage = action.execute(request);
     this.dispatch(request, response, nextPage);
  }

  private void dispatch(HttpServletRequest request, HttpServletResponse response,String page)throws ServletException,
      IOException {
     RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(page) ;
     dispatcher.forward (request, response);
  }


  //Get Servlet information
  public String getServletInfo() {
    return "controller.FrontController Information";
  }
  
  
}
