/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dispatchers;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import utility.AdmitBookStoreDAO;

/**
 *
 * @author Eric
 */
public class titleDispatcher implements dispatcher {

    @Override
    public String execute(HttpServletRequest request) {
        
        AdmitBookStoreDAO dao = new AdmitBookStoreDAO("jdbc/JavaDB_BooksDB");
        List books = null;
        String nextPage = null;
        HttpSession session = request.getSession();
        try
        {
            books = dao.getAllBooks();
            
            if( books != null )
            {
                session.setAttribute("books", books);
                nextPage = "/jsp/titles.jsp";
            }
        }
        catch(Exception e)
                {
                    request.setAttribute("result", e.getMessage());
                    nextPage = "/jsp/error.jsp";
                }
        return nextPage;

    }
    
}
